/* 
 * File:   Stack.h
 * Author: admin
 *
 * Created on October 7, 2015, 10:26 AM
 */

#ifndef STACK_H
#define	STACK_H

#include "LnkList.h"

template <class T>
class Stack: public LnkList<T> {
    private:
    public:
        Stack():LnkList<T>() {};
        Stack(int);
        ~Stack() {};
    
        
};

//template <class T>
//Stack<T>::Stack(int n) {
//    if(n<=0) head=nullptr;
//    else {
//        List *node;
//        node=head;
//        for(int i=0;i<n;i++) {
//            node=new List;
//            node=node->next;
//        }
//    }
//}

#endif	/* STACK_H */

