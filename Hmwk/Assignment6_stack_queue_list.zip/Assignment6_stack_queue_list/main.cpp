/* 
 * File:   main.cpp
 * Author: admin
 *
 * Created on October 7, 2015, 10:25 AM
 */

#include <iostream>
using namespace std;

#include "Stack.h"
int main(int argc, char** argv) {
    Stack<int> x;
    return 0;
}

